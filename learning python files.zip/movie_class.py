#This is to learn how to create a class by creating a class, "Movie," that
#includes Title, Storyline, Poster_image, Youtube_trailer
#Style guide says class should be capitalized and a class variable that is not likely to
#change should be in all CAPS. The 2 underscores on both sides of
#init indicate it is a dedicated reserved internal special python function. Init takes 2
#arguments, self & the information class receives.
#Self is the instance being created. 

import webbrowser

class Movie():
    """This class provides a way to store and access movie related information."""
    #The triple quotes create documentation for the class. This utilizes the built in __doc__ function
    VALID_RATINGS= ["G","PG","PG-13","R"] #class variable, outside init function
    
    def __init__(self, movie_title, movie_storyline, poster_image, youtube_trailer):
        self.title = movie_title
        self.storyline = movie_storyline
        self.poster_image_url = poster_image
        self.trailer_youtube_url = youtube_trailer
#a function defined within a class is called an Instance Method

    def show_trailer(self):
        webbrowser.open(self.trailer_youtube_url)

#download file "fresh_tomatoes.py"
