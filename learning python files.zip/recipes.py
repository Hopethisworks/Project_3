# -*- coding: cp1252 -*-
#above was added by Python

import cookbook

tart = cookbook.Recipe ("Savory Spring Vegetable and Goat Cheese Tart",
                        "A handful of fresh herbs, asparagus spears, and spring onions shine in this elegant savory tart.",
                        "http://www.epicurious.com/recipes/food/views/savory-spring-vegetable-and-goat-cheese-tart-395442")
#print(tart.title)

omlet_mix = cookbook.Recipe ("Chickpea Omelet Mix",
                             "This mix is generically seasoned, making omelets that adapt to any kind of cuisine. Feel free to add additional seasonings depending on your mood or the filling you use�for instance, garam masala for an Indian flavor or chili powder or chipotle for a black bean filling.",
                             "http://blog.fatfreevegan.com/2014/12/chickpea-omelet-mix.html")

enchiladas = cookbook.Recipe ("Cheese and Pepper Enchiladas",
                              "Serrano or jalape�o chiles are both tasty in this recipe.",
                              "http://www.wholefoodsmarket.com/recipe/cheese-and-bell-pepper-enchiladas")

#omlet_mix.open_recipe()
print cookbook.Recipe.__module__
print cookbook.Recipe.__name__

