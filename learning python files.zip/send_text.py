#First had to download Twilio - external Python package from python.org. There are
#lots of external packages you can download
#Next, Twilio has sample code you can download and play with here: https://www.twilio.com/docs/python/install

from twilio import rest
# Your Account Sid and Auth Token from twilio.com/user/account
account_sid = "AC0eb48a63ebf46d2486ee43a89db432b2"
auth_token = "1b20d491c52e6ae17c97e6ee640d7833"
client = rest.TwilioRestClient(account_sid, auth_token)
message = client.messages.create(body="Just another test message in paradise",
to="+16019195638", # Replace with your phone number
from_="+16468876477") # Replace with your Twilio number
print message.sid
