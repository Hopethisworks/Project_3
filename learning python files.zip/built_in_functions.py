#this was an assignment to test out built in functions.

#"enumerate" looks interesting, may be able to use it with the HTML generator at some point:
#the built in class "List" is used with enumerate:

def experiment():
    functions = ['Open','Close','Read','Enumerate','Help','List']
    list(enumerate(functions))
    print functions

experiment()

#that didn't work, so I tried again with simple min and max, pasted
#directly into the shell

print min(568.3,857,16875.2,19)
print max(568.3,857,16875.2,19)

#I also got this to work - range returns the numbers 0 to the range attribute number
#this could be very helpful for loops

def loop1():
    first = range(10)#should return 0,1,2,3,4,5,6,7,8,9
    second = range(0,-4,-1)#should return 0,-1,-2,-3
    third = first + second
    print third
loop1() #should return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, -1, -2, -3]
