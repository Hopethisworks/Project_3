#To use the webbrowser functionality that you find by looking it up,
#you must import the entire webbrowser functionality from Python
#Standard Library. This includes the webbrowser.open funciont. Same
#for the time functionality, which includes time.sleep and time.ctime

import webbrowser
import time

total_breaks = 3
break_count = 0

print("This program started on "+time.ctime())
#time.ctime is a function you have to look up, it returns current time

while(break_count < total_breaks):
    time.sleep(2*60*60)
    webbrowser.open("https://www.youtube.com/watch?v=aemXgP-2xyg")
    break_count = break_count + 1
