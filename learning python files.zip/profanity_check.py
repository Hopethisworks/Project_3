#This creates a function to check a document for profanity. Need 2 steps:
#1 read contents of a file
#2 check contents for profanity
#Open and read and close are built in functions in the python library and don't need to be imported
import urllib

def read_text():
    quotes = open("C:\Python27\movie_quotes_profanity.txt")
    contents_of_file = quotes.read()
    print(contents_of_file)
    quotes.close()
    check_profanity(contents_of_file)

#found profanity definitions at http://www.wdyl.com type in profanity?q, type = then test word
#he knew to use the module urllib with function urlopen which takes a link to site,must import

def check_profanity(text_to_check):
    connection = urllib.urlopen("http://www.wdyl.com/profanity?q="+text_to_check)
    response = connection.read()
    #print(response) #this was removed to add the if statement for a friendlier output
    connection.close()
    if "true" in response:
        print("Profanity Alert!")
    elif "false" in response:
        print("This document has no profanity")
    else:
        print("Document not scanned properly")


read_text()    
