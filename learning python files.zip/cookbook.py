#This is an experiment to create a class to use Module and Name class functions

import webbrowser

class Recipe():
    """This class provides a way to store and access recipes from various sources."""
    CATEGORIES= ["Breakfast","Appetizers/Small Meals","Entrees","Sides","Breads","Desserts"]

    def __init__(self, recipe_title, recipe_description, recipe_source):
        self.title = recipe_title
        self.description = recipe_description
        self.recipe_url = recipe_source

    def open_recipe(self):
        webbrowser.open(self.recipe_url)

        
