#Python os library function is operating system.  It includes os.listdr to find
#files in a directory, takes in path for folders. If you use 'r' before the directory
#it means 'raw' or do not try to interpret the string any other way.
#os.rename(source,new_name ) renames the file.
#string.translate(table, list of all characters to remove from string)

import os

def rename_files():
     #1) get file names from a folder
    file_list = os.listdir(r"D:\Documents\Website\Prank_files")
    print (file_list)

#I had a problem here that it couldn't find the files.  Turns out that is normal.
#Here is how to fix it.  The library function os.getcwd() tells you your current working directory.
#print it out so you can see:
    saved_path = os.getcwd()
    print ("Current Working Directory is "+saved_path)
#returns "Current Working Directory is D:\Python27"
#to fix this you have to change directory with os.chdir, but don't forget to change it back!!

    os.chdir(r"D:\Documents\Website\Prank_files")
    # 2) for each file, rename filename
    for file_name in file_list:
        print ("Old Name - "+file_name)
        print ("New Name - "+file_name.translate(None,"0123456789"))
        os.rename(file_name, file_name.translate(None,"0123456789"))
    os.chdir(saved_path)
rename_files()


