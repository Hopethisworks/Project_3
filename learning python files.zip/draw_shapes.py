#function to draw a square uses a function in python called TURTLE -
#this allows you to draw in Python

import turtle

def draw_square(some_turtle):
    for number in range(1,5):
        some_turtle.forward(100)
        some_turtle.right(90)
#this loop runs four times

def draw_art():
    window = turtle.Screen()
    window.bgcolor("blue")
#create the turtle brad to draw a square
    brad = turtle.Turtle()
    brad.shape("turtle")
#valid shapes = arrow, turtle, circle, square, triangle, classic
    brad.color("red")
    brad.speed(2)
#0 is fastest-no animation takes place but is instant, 10 is fast, 1 is slowest
    for i in range (1,37):
        draw_square(brad)
        brad.right (10)
        #this runs 36 times to go 360 degrees
#create the turtle angie to draw a circle; commented out to create the circle from the squares
#    angie = turtle.Turtle()
#    angie.shape("classic")
#    angie.color("green")
#    angie.circle(80)
    
    window.exitonclick()
    
draw_art()
    

