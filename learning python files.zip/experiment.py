import turtle

def draw_triangle(triangle):
    for number in range(1,4):
        triangle.forward(80)
        triangle.right(120)

def draw_art():
    window = turtle.Screen()
    window.bgcolor("black")
    center = turtle.Turtle()
    center.shape("circle")
    center.color("yellow")
    center.fillcolor("yellow")
    center.circle(80)
    triangle = turtle.Turtle()
    triangle.shape("triangle")
    triangle.color("green")
    triangle.speed(2)
    draw_triangle(triangle)

    window.exitonclick()
    
draw_art()
    
